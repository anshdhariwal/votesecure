# 🗳️ VoteSecure: Modern Election Lifecycle Management

**VoteSecure** is a high-end, secure digital voting platform designed to manage the entire lifecycle of an election—from registration and active balloting to manual conclusion and celebratory result declaration.

---

## 🚀 Getting Started (First-Time Usage)

To get the project up and running on your local machine for the first time, follow these steps:

### 1. Prerequisites
Ensure you have **Python 3.10+** and **pip** installed.

### 2. Install Dependencies
Open your terminal in the project root and run:
```bash
pip install -r requirements.txt
```

### 3. Populate Test Data
To quickly see the platform in action with real-world candidates and parties, run:
```bash
python testdata.py
```
*This will create the "National General Elections 2025", 2 positions (PM & President), and set up the default voter: **shivansh@vote.com** (Password: **shivansh**).*

### 4. Run the Server
```bash
python manage.py runserver
```
Visit `http://127.0.0.1:8000/` to begin.

---

## 🎭 User Roles & Operations

The platform distinguishes between two primary user types with specific permissions:

### **1. Admin (ECI Official)**
*   **Election Management**: Create, edit, and delete elections with custom timelines.
*   **Candidate Control**: Manage candidate profiles, biographies, and manifestos.
*   **Lifecycle Control**: Manually **Conclude** elections to freeze voting and trigger results.
*   **Reporting**: Export detailed, encrypted PDF result reports for archived elections.
*   **Voter Oversight**: View and manage the voter register.

### **2. Voter (The Citizen)**
*   **Secure Registration**: Two-step signup process with eligibility (18+) verification.
*   **Candidate Portal**: Explore "Meet the Candidates" to read manifestos and goals.
*   **Smart Balloting**: Interactive, multi-position voting interface with review and confirm steps.
*   **Celebratory Dashboard**: Real-time participation tracking and result announcements.
*   **Winners View**: Visualize election winners with a golden crown icon once results are out.

---

## ✨ Key Features on Board

*   **🏆 Winner Visualization**: Automatic winner determination based on vote counts, highlighted with a golden crown icon across all interfaces.
*   **📜 Reusable Candidate Modals**: Consistent, high-fidelity overlays for candidate bios and manifestos.
*   **🔒 Irreversible Voting**: Multi-modal confirmation logic to ensure votes cannot be changed or withdrawn once cast.
*   **📊 Dynamic Results**: Real-time turnout percentages and ranking lists for concluded elections.
*   **🎨 Material Dark Aesthetic**: A premium, "Material-inspired" design system with glassmorphism and subtle micro-animations.
*   **📄 PDF Security**: Administrative result reports are locked until an election is officially concluded.
*   **📱 Fully Responsive**: Seamless experience across mobile, tablet, and desktop devices.

---

## 🛠️ Technical Stack
*   **Backend**: Django (Python)
*   **Frontend**: Tailwind CSS (Custom Theme), JavaScript (Vanilla)
*   **Database**: SQLite (Default)
*   **PDF Engine**: xhtml2pdf

---

**Developed with precision for a secure democracy.**
